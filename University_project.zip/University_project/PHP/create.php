<?php
   
    /**
     * The function cleans and sanitizes input data by removing HTML tags, special characters, and
     * slashes.
     * 
     * @param data  is a variable that represents the input data that needs to be cleaned and
     * sanitized. It could be any type of data such as a string, an array, or an object. The purpose of
     * the function is to remove any potentially harmful characters or tags from the input data to
     * prevent security vulnerabilities or unexpected
     * 
     * @return the cleaned and sanitized version of the input data.
     */
    function cleanData($data){
      $data = htmlspecialchars($data);
      $data = strip_tags($data);
      $data = stripslashes($data);
      return $data;
    }


    /**
     * The function checks if a given name contains only letters and certain Arabic characters.
     * 
     * @param name The parameter "name" is a string variable that represents a person's name.
     * 
     * @return a boolean value (true or false) depending on whether the input string contains only
     * letters (including Arabic and Persian letters) or not.
     */
    function check_name($name) {
      
      $regex = '/[a-zA-Z\x{0600}-\x{06FF}\x{0750}-\x{077F}]/u';

      if(preg_match($regex, $name)) { // Check if the regular expression matches
        return true;
      } 
      else {
        return false;
      }
      
  }


require_once('connctDB.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    //اضافة البيانات بعد التحقق منها 
    if(isset($_POST['username']) && isset($_POST['first_name'])  && isset($_POST['last_name'])  
    && isset($_POST['email']) && isset($_POST['password']) && isset($_POST['is_doctor']) ) {

      
        /* This code block is checking if the value of the `is_doctor` field in the submitted form is
        equal to "student". If it is, then it creates an SQL query to insert the form data into the
        `students` table in the database. The query includes the values of the `username`,
        `first_name`, `last_name`, `email`, and `password` fields from the submitted form, as well as
        two `NULL` values for the last two columns in the `students` table. */
        if($_POST['is_doctor'] == "student"){

          $sql = "INSERT INTO `students` (`student_id`, `first_name`, `last_name`, `email`, `password`, `leverage` , `id_room`)
          VALUES ('" . $_POST['username'] . "', '" . $_POST['first_name'] . "', '" . $_POST['last_name'] . "',
          '" . $_POST['email'] . "', '" . $_POST['password'] . "', '2', NULL)";

        }
       

        
        /* This code block is checking if the value of the `is_doctor` field in the submitted form is
        equal to "doctor". If it is, then it creates an SQL query to insert the form data into the
        `doctor` table in the database. The query includes the values of the `username`, `first_name`,
        `last_name`, `email`, and `password` fields from the submitted form, as well as a value of `1`
        for the last column in the `doctor` table. */
        else{
          $sql = "INSERT INTO `doctor` VALUES ('" . $_POST['username'] . "',
          '" . $_POST['first_name'] . "', '" . $_POST['last_name'] . "', '" . $_POST['email'] . "',
            '" . $_POST['password'] . "', '1')";
        }
        /* This code block is trying to execute an SQL query to insert data into a database table using
        the `` variable. If the query is successful, it will print a message "Data added
        successfully". However, if there is an error in executing the query, it will catch the
        exception and print an error message "There is an error in the added data" along with the
        specific error message returned by the database. */
        try {
          $conn->query($sql);
          echo 'success';
        } 
        catch (mysqli_sql_exception $e) {
            // لا تفعل شيئًا هنا إن كنت لا تريد أن يتم إظهار رسالة الخطأ
            // يمكنك استخدام $e للتحقق من نوع الخطأ واتخاذ إجراءات مناسبة للتعامل معه
            echo 'There is an error in the added data  : ' .   mysqli_error($conn);
        }
  }






      // create rooms   -------file => create_room.js-------

  /* This code block is checking if the `creat_room`, `username`, and `title` variables are set in the
  `` array. If they are set, it then trims the values of the `username` and `title` variables
  and checks if there is already a room with the same title in the `room` table in the database. If
  there is, it prints a message "sorry there is a room with this name" and exits the script. If there
  isn't, it inserts a new row into the `room` table with the values of `title` and `username`
  variables and prints a message "success". */
  if(isset($_POST['creat_room']) && isset($_POST['username']  )&& isset($_POST['title']  )  && isset($_POST['description']  )){ 
    $username=trim($_POST['username'])  ;
    $description=trim($_POST['description'])  ;
    $title=trim($_POST['title']) ;
    $bool=true; // you can deleted
    $rooms=mysqli_fetch_all( mysqli_query($conn,"SELECT  title FROM room"),MYSQLI_ASSOC); 
    foreach ($rooms as $room) {
      if($title == $room['title']){
        $bool=false;
        echo( "sorry there is a room with this name" ) ; 
        exit;
      }
    }
    if( $bool == true){ 
      $arRroom= mysqli_query($conn,"INSERT INTO `room`( `title`, `doctor_id`, `description`) VALUES ('{$title}','{$username}','{$description}')"); 
      mkdir("../uplode/". $title , 0777);
      chmod("../uplode/". $title , 0777);

      
      echo( "suecssfly" ) ; 
      exit;

    }



  } 
  


  // <! -!!! Not checked!!! ->
  if(isset($_POST['seveprofile']) && isset($_POST['username'] ) ){ 
      
    if(isset($_POST['first_name']) && isset($_POST['last_name'] ) &&isset($_POST['email'] )){ 
      $username=trim($_POST['username']);																		
      $q = mysqli_query($conn, "UPDATE students SET first_name='{$_POST['first_name']}', last_name='{$_POST['last_name']}', email='{$_POST['email']}' WHERE student_id='$username'");
      $q = mysqli_query($conn, "UPDATE doctor SET first_name='{$_POST['first_name']}', last_name='{$_POST['last_name']}', email='{$_POST['email']}' WHERE doctor_id='$username'");

      if(isset($_POST['password']) && isset($_POST['confirm_password'])) {
        $password = trim($_POST['password']);
        $confirm_password = trim($_POST['confirm_password']);
      
        if ((strlen($password) > 30 || strlen($password) <=3)  ) {
          // إذا كانت كلمة المرور أقل من 8 أحرف
          echo "يجب أن تحتوي كلمة المرور على 8 أحرف على الأقل";
        } elseif ($password !== $confirm_password) {
          // إذا كلمة المرور لا تتطابق مع تأكيد كلمة المرور
          echo "كلمة المرور وتأكيد كلمة المرور غير متطابقين";
        } else {
          $q = mysqli_query($conn, "UPDATE students SET password='{$_POST['password']}' WHERE student_id='$username'");
          $q = mysqli_query($conn, "UPDATE doctor SET password='{$_POST['password']}' WHERE doctor_id='$username'");

      } 
    }
    exit;
    }

  }


  /* The above code is a PHP script that performs various form validation tasks based on the values of
  the POST variables received from a form submission. */
  if(isset($_POST['creat_note']) && isset($_POST['query']  )&& isset($_POST['room_id']  )){ 
    
      $room_id=trim($_POST['room_id']) ;
      mysqli_query($conn,trim($_POST['query'])); 
      $arrNote=mysqli_fetch_all( mysqli_query($conn,"select *  from note WHERE room_id ='{$room_id}'"),MYSQLI_ASSOC); 

    if($arrNote!=null){ 
      echo(  json_encode($arrNote) ) ; 
      exit;
    }else{
      echo "smothing wrong1";
    }
    }
    

    // <! -!!! Not checked!!! ->





    
    //_________----------------------------------------------------------------------------------------------

      // التحقق من user name  
      if(isset($_POST['username'])){

        if(empty($_POST["username"])){
          echo "This field is required !";
        }
        else{
          if(preg_match('/^[a-z\d_]{3,45}$/i', $_POST['username']) == false){
            echo "Username must be letters / numbers / more than 3 characters";
          }
          else{
              try {
                $arrstu=mysqli_fetch_all( mysqli_query($conn,"select student_id from students"),MYSQLI_ASSOC);
                $arrdoc=mysqli_fetch_all( mysqli_query($conn,"select doctor_id  from doctor"),MYSQLI_ASSOC);
                
                foreach ($arrstu as $student) {
                  if( $student['student_id'] == strtolower($_POST['username']) ){

                    exit("sorry user name already exist");
                  }        
                }
                foreach ($arrdoc as $doctor_) {
                  if( $doctor_['doctor_id'] == strtolower($_POST['username']) ){

                    exit("sorry user name already exist");
                  }        
                }
                echo $_POST["username"];

              } 
            catch (exception $e) {
                // لا تفعل شيئًا هنا إن كنت لا تريد أن يتم إظهار رسالة الخطأ
                // يمكنك استخدام $e للتحقق من نوع الخطأ واتخاذ إجراءات مناسبة للتعامل معه
                echo 'an error occurred: '  . $e->getMessage();
            }


          }
        }
          
              


        
          $arrstu=mysqli_fetch_all( mysqli_query($conn,"select student_id from students"),MYSQLI_ASSOC);
          $arrdoc=mysqli_fetch_all( mysqli_query($conn,"select doctor_id  from doctor"),MYSQLI_ASSOC);
          
          foreach ($arrstu as $student) {
              if( $student['student_id']==$_POST['username']){
                  exit("sorry user name already exist");
              }      
        }  
        foreach ($arrdoc as $doctor_) {
          if( $doctor_['doctor_id']==$_POST['username']){
            exit("sorry user name already exist");
          } 
                  
        }
      }
      

        // التحقق من first_name   
      if(isset($_POST['first_name'])){
        if(empty($_POST["first_name"])){
          echo "This field is required!";
        }
        else{

          if( (check_name($_POST["first_name"])) == false  || (cleanData($_POST["first_name"]) !== $_POST["first_name"])){
            echo "Please enter a valid value !";
          }
          else{

            echo  $_POST["first_name"] ;  
          }      
      }
      }
    
    

        // التحقق من last_name   
      if(isset($_POST['last_name'])){
        if(empty($_POST["last_name"])){
          echo "This field is required!";
        }
        else{
          if( (check_name($_POST["last_name"])) == false  || (cleanData($_POST["last_name"]) !== $_POST["last_name"])){
            echo "Please enter a valid value !";
          }
          
          else{
            echo  $_POST["last_name"];  
          }      
      }
      }
      


        // التحقق من email   
      if(isset($_POST['email'])){
        if(empty($_POST["email"])){
          echo "This field is required!";
        }
        else{
          if((filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) == false){
            echo "Please enter a valid value !";
          }
          else{
            echo $_POST["email"];

          }

          
        }
      }

        // التحقق من password   
      if(isset($_POST['password'])){
        if(empty($_POST["password"])){
          echo "This field is required !";
        }
        else{
          if(preg_match('/^[a-z\d_@]{8,30}$/i', $_POST['password']) == false){
            echo "password must than 8 characters";
          }
          else{
            echo $_POST['password'];

          }

          
        }
      }
    
    else{
          echo "this is no value in the variable ^__^";
    }

  


      




      
  }

else {

  echo "The request is not _post";
}





?>