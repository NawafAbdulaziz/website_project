<?php 
	require_once('connctDB.php'); 
if ($_SERVER['REQUEST_METHOD'] == 'POST') { 
	
	
	
	function check_pass($password){
		if(empty($password) ){
			echo "This field is required !";
			}
			else{
			if(preg_match('/^[a-z\d_@]{8,30}$/i', $password) == false){
				echo "password must than 8 characters";
			}
			else{
				return $password;
	
			}
	
			
			}
	}


	


		//finsh  => -----------file => join_rooms.js -----------


	/* This code block is checking if the POST request contains the parameters 'room', 'username', and
    'join_room'. If these parameters are present, it proceeds to check if the user with the given
    username is already registered in a room. If not, it checks if the room ID provided in the POST
    request exists in the database. If it does, it updates the 'id_room' field of the user with the
    provided username to the room ID and inserts a new record in the 'text_box' table with the room ID
    and student ID. Finally, it outputs a success message. If the user is already registered in a room,
    it outputs an error message. If the room ID provided does not exist in the database, it also
    outputs an error message. */
    if(isset($_POST['room']) && isset($_POST['username']  )&& isset($_POST['join_room']  )){ 
		$username=trim($_POST['username']) ;

		//اضافه شرط تحقق اذا كان الطالب مسجل في روم او غرفه من قبل
		$check=mysqli_fetch_all( mysqli_query($conn,"SELECT `id_room` FROM `students` WHERE `student_id` = '$username' "),MYSQLI_ASSOC); 

		if($check[0]['id_room'] == null){

			$room=trim($_POST['room']) ;
			$bool=false;
			$rooms=mysqli_fetch_all( mysqli_query($conn,"SELECT  id FROM room"),MYSQLI_ASSOC); 

			//chick id room
			foreach ($rooms as $roomID) {
				if($room == $roomID['id']){
					$bool=true;
				}
				}
			if( $bool == true){ 
				$arRroom= mysqli_query($conn,"UPDATE `students` SET `id_room`=$room WHERE student_id ='$username'"); 
				mysqli_query($conn,"INSERT INTO `text_box`(`room_id`, `student_id`) VALUES ('$room','$username');"); 
				echo( "You have been registered successfully" ) ; 
				exit;
			
			}else{
				echo "There is no room with this id";
				exit;
			}
		}else{
			echo "It is not allowed to register in more than one room";
			exit;

		}
	}



	//_______________________________________________________________________________________________________


	

	/* This code block is checking if the POST request contains the parameters 'update_note', 'query', and
	'room_id'. If these parameters are present, it proceeds to execute a SQL query to update the note
	in the database with the provided query and room ID. Then, it fetches all the notes from the 'note'
	table in the database with the provided room ID and outputs them as a JSON-encoded array. If there
	are no notes with the provided room ID, it outputs an error message. */
	if(isset($_POST['update_note']) && isset($_POST['query']  )&& isset($_POST['room_id']  )){ 
		$room_id=trim($_POST['room_id']) ;
    	mysqli_query($conn,trim($_POST['query'])); 
        $arrNote=mysqli_fetch_all( mysqli_query($conn,"select *  from note WHERE room_id ='{$room_id}'"),MYSQLI_ASSOC); 

		if($arrNote!=null){ 
			echo(  json_encode($arrNote) ) ; 
			exit;

		}else{
			echo "smothing wrong1";
		}
    }

	if(isset($_POST['delete_note']) && isset($_POST['query']  )&& isset($_POST['room_id']  )){ 
		$room_id=trim($_POST['room_id']) ;
    	mysqli_query($conn,trim($_POST['query'])); 
        $arrNote=mysqli_fetch_all( mysqli_query($conn,"select *  from note WHERE room_id ='{$room_id}'"),MYSQLI_ASSOC); 

		if($arrNote!=null){ 
			echo(  json_encode($arrNote) ) ; 
			exit;

		}else{
			echo "null";
		}
    }

	if(isset($_POST['password'])  && isset($_POST['confirm_password']) && isset($_POST['reset_pass'])&& isset($_POST['username']) ){ 
		$password=check_pass($_POST['password']); 
		$username=trim($_POST['username']); 
		if($password==$_POST['confirm_password']){

		
		$arrdoc = mysqli_fetch_all(mysqli_query($conn, "SELECT doctor_id, password FROM doctor WHERE doctor_id = '{$username}'"), MYSQLI_ASSOC);
		$arrstu=mysqli_fetch_all( mysqli_query($conn,"select student_id ,password from students WHERE student_id = '{$username}'"),MYSQLI_ASSOC); 
			
			if($arrstu!=null){ 
				echo mysqli_query($conn, "UPDATE students SET password = '{$password}' WHERE student_id = '$username'"); 

					exit(); 
					
			}
			if($arrdoc!=null){ 
			echo mysqli_query($conn, "UPDATE doctor SET password = '{$password}' WHERE doctor_id = '$username'"); 
				
				exit(); 
					
			}
		}
	}
		


		
	}
?>