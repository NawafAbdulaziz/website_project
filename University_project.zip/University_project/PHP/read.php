<?php 
	require_once('connctDB.php'); 
	if ($_SERVER['REQUEST_METHOD'] == 'POST') { 
	
	    //**** that useing by -----login.js-----

	
		/* This code block is checking if the HTTP request method is POST and if the 'login' parameter is set
		in the POST request. If it is set, it checks if the 'username' and 'password' parameters are also
		set in the POST request. If both parameters are set, it retrieves the password of the student or
		doctor with the given username from the 'students' or 'doctor' table in the database using a SQL
		query. It then checks if the password matches the one provided in the POST request. If it matches,
		it prints "success" and exits the script. If it does not match, it prints "username or password is
		wrong" and exits the script. */
		if(isset($_POST['login'] )){ 
			if(isset($_POST['username'] ) && isset($_POST['password'] )){ 
				$username=trim($_POST['username']);	
																					
				$arrdoc = mysqli_fetch_all(mysqli_query($conn, "SELECT doctor_id, password FROM doctor WHERE doctor_id = '{$username}'"), MYSQLI_ASSOC);
				$arrstu=mysqli_fetch_all( mysqli_query($conn,"select student_id ,password from students WHERE student_id = '{$username}'"),MYSQLI_ASSOC); 
				if($arrstu!=null){ 
					if( $arrstu[0]['password']==trim($_POST['password'])){ 
						echo "success"; 
						exit(); 
					}       
				}
				if($arrdoc!=null){ 
					if( $arrdoc[0]['password']==trim($_POST['password'])){ 
						echo "success"; 
						exit(); 
					}       
				}
			exit("username or password is wrong "); 	
			} 
		}




		// the request to give rooms for username and display   ---file=> home.js----


		/* This code block is checking if the HTTP request method is POST and if the 'get_room' parameter is
		set in the POST request. If it is set, it checks if the 'username' parameter is also set in the
		POST request. If both parameters are set, it retrieves the room information (id, title, and
		description) associated with the given 'username' from the 'room' table in the database using a SQL
		query. If the user is a student, it retrieves the 'id_room' associated with the student from the
		'students' table and uses it to retrieve the room information from the 'room' table. If the user is
		a doctor, it retrieves the room information directly from the 'room' table using the 'doctor_id'.
		Finally, it encodes the resulting array as a JSON object and prints it to the output. If there is
		an error, it prints "something wrong". */
		if(isset($_POST['get_room'] )){ 
			if(isset($_POST['username'] ) ){ 

				$username=trim($_POST['username']);																		


				
				// Give me the id_room in the table student
				$arrstu=mysqli_fetch_all( mysqli_query($conn,"select id_room  from students  WHERE student_id = '{$username}'"),MYSQLI_ASSOC); 

				// Give me the doctor_id in the table room and title
				$arrdoc=mysqli_fetch_all( mysqli_query($conn,"select id,title,description  from room WHERE doctor_id = '{$username}'"),MYSQLI_ASSOC); 

				if($arrstu!=null){ 
				// Give me the doctor_id in the table room and title
					$arrRoom=mysqli_fetch_all( mysqli_query($conn,"select id,title,description  from room WHERE id = '{$arrstu[0]['id_room']}'"),MYSQLI_ASSOC); 

					//this is responce 
					print_r(  json_encode($arrRoom) ) ; 
					exit;   
				}
				
				if($arrdoc!=null){ 

					//this is responce 
					print_r(  json_encode($arrdoc) ) ; 
					exit;   
				}
				else{
					echo "smothing wrong";
					exit;   
				}
				//
			}
		}



		//get_leverage and store in session Storage   -----file =>home.js------

		/* This code block is checking if the HTTP request method is POST and if the 'get_leverage' parameter
		is set in the POST request and if the 'username' parameter is also set in the POST request. If both
		parameters are set, it retrieves the leverage of the student or doctor with the given username from
		the 'students' or 'doctor' table in the database using a SQL query. It then prints the leverage to
		the output and exits the script. If there is an error, it prints "something wrong". */
		if(isset($_POST['get_leverage'] )&& isset($_POST['username'] )){ 

			$username=trim($_POST['username']);																		

			$arrstu=mysqli_fetch_all( mysqli_query($conn,"select leverage  from students  WHERE student_id = '{$username}'"),MYSQLI_ASSOC); 
			$arrdoc=mysqli_fetch_all( mysqli_query($conn,"select leverage  from doctor WHERE doctor_id = '{$username}'"),MYSQLI_ASSOC); 

			if($arrstu!=null){ 

				echo $arrstu[0]['leverage'] ; 
				exit;   
			}
			
			if($arrdoc!=null){ 
				echo $arrdoc[0]['leverage'] ; 
				exit;   
			}
			else{
				echo "smothing wrong";
			}
			
			

		}



		// يجيب المعلومات من قاعدج البيانات ويقدر يسوي تعديل   -----file => profile.js-----

		/* This code block is checking if the HTTP request method is POST and if the 'getdata' parameter is
		set in the POST request. If it is set, it checks if the 'username' parameter is also set in the
		POST request. If both parameters are set, it retrieves the email, last name, and first name of the
		student or doctor with the given username from the 'students' or 'doctor' table in the database
		using a SQL query. It then encodes the resulting array as a JSON object and prints it to the
		output. Finally, it exits the script. */
		if(isset($_POST['getdata'])){ 
			if(isset($_POST['username'])){ 

				$username=trim($_POST['username']);																		

				$arrstu=mysqli_fetch_all( mysqli_query($conn,"select email,last_name,first_name  from doctor WHERE doctor_id = '{$username}'"),MYSQLI_ASSOC); 
				$arrdoc=mysqli_fetch_all( mysqli_query($conn,"select email,last_name,first_name  from students WHERE student_id = '{$username}'"),MYSQLI_ASSOC); 

				if($arrstu!=null){ 
					print_r(  json_encode($arrstu) ) ; 
					exit;
		
				}
				if($arrdoc!=null){ 
					print_r(  json_encode($arrdoc) ) ; 
					exit;
		
				}
				
		}


		}



		//_______________________________________________________________________________________________________


	


		/* This code block is checking if the HTTP request method is POST and if the 'get_notes' and 'room_id'
		parameters are set in the POST request. If both parameters are set, it retrieves all the notes
		associated with the given 'room_id' from the 'note' table in the database using a SQL query. If
		there are notes associated with the room, it encodes the resulting array as a JSON object and prints
		it to the output. If there are no notes associated with the room, it prints "The room has no Notes"
		to the output. */
		if(isset($_POST['get_notes'] )){ 
			if(isset($_POST['room_id'] ) ){ 

				$room_id=trim($_POST['room_id']);																		

				$arrNote=mysqli_fetch_all( mysqli_query($conn,"select *  from note WHERE room_id = '{$room_id}'"),MYSQLI_ASSOC); 

				if($arrNote!=null){ 
					print_r(  json_encode($arrNote) ) ; 
					exit;
		
				}else{
					echo "The room has no Notes";
				}
				
			}
		}


		/* This code block is checking if the HTTP request method is POST and if the 'get_stu' and 'room_id'
		parameters are set in the POST request. If both parameters are set, it retrieves the list of
		students with the given 'room_id' from the 'students' table in the database using a SQL query. If
		there is an additional 'query' parameter in the POST request, it executes that SQL query before
		retrieving the list of students. If there is an additional 'delete' parameter in the POST request,
		it updates the 'id_room' field of the student with the given 'delete' parameter to NULL in the
		'students' table. Finally, it encodes the resulting array as a JSON object and prints it to the
		output. */
		if(isset($_POST['get_stu']) && isset($_POST['room_id']  )){ 
			

			if(isset($_POST['query'] )){ 
			mysqli_query($conn,trim($_POST['query']));
			
				if(isset($_POST['delete'] )){

					mysqli_query($conn, "UPDATE `students` SET `id_room` = NULL WHERE `students`.`student_id` ='" . $_POST['delete'] . "'");
				}
			}

			$room_id=trim($_POST['room_id']);


			$arrstud=mysqli_fetch_all(mysqli_query($conn,"SELECT student_id,first_name,last_name,id_room FROM students WHERE id_room='{$room_id}'") ,MYSQLI_ASSOC); 
			
			if($arrstud!=null){ 
				echo( json_encode($arrstud) ) ; 
				exit;

			}else{
				echo "null";
			}
			}
		//




		/* This code block is checking if the HTTP request method is POST and if the 'query' and
		'specific_stud' parameters are set in the POST request. If both parameters are set, it executes the
		SQL query specified in the 'query' parameter and retrieves the resulting data for a specific
		student. It then encodes the resulting array as a JSON object and prints it to the output. If there
		is an error or no data is retrieved, it prints "null specific_stud" to the output. */
		if(isset($_POST['query']  )&& isset($_POST['specific_stud']  )){ 

				$arrstu=mysqli_fetch_all( mysqli_query($conn,trim($_POST['query'])),MYSQLI_ASSOC); 

				if($arrstu!=null){ 
					echo(  json_encode($arrstu) ) ; 
					exit;

				}else{
					echo "null specific_stud";
				}
			}

		////



		/* This code block is checking if the HTTP request method is POST and if the 'boxs' parameter is set in
		the POST request. If it is set, it checks if the 'query', 'content', and 'id_box' parameters are
		also set in the POST request. If all parameters are set, it updates the 'content' field of the
		'text_box' table with the given 'id_box' to the value of the 'content' parameter using a SQL query.
		If the 'room' parameter is also set in the POST request, it retrieves all the text boxes associated
		with the given 'room_id' from the 'text_box' table in the database using another SQL query. If there
		are text boxes associated with the room, it encodes the resulting array as a JSON object and prints
		it to the output. If there are no text boxes associated with the room, it prints "something wrong"
		to the output. */
		if(isset($_POST['boxs'] )){
			if(isset($_POST['query'] )&&isset($_POST['content'] )&&isset($_POST['id_box'] ) ){
				$content=$_POST['content'];
				$id=$_POST['id_box'];
				mysqli_query($conn,"UPDATE text_box SET content ='$content' WHERE id =$id");
			}

			if(isset($_POST['room'] ) ){ 

				$room_id=trim($_POST['room']);																		

				$boxNote=mysqli_fetch_all( mysqli_query($conn,"select *  from text_box WHERE room_id='{$room_id}'"),MYSQLI_ASSOC); 

				if($boxNote!=null){ 
					print_r(  json_encode($boxNote) ) ; 
					exit;
		
				}else{
					echo "smothing wrong";
				}
				
			}
		}



		if(isset($_POST['forgot'])&&isset($_POST['username'] )){  
			
			$username=trim($_POST['username']);                   
			
			$arrdoc=mysqli_fetch_all( mysqli_query($conn,"select email  from doctor WHERE doctor_id = '{$username}'"),MYSQLI_ASSOC);  
			$arrstu=mysqli_fetch_all( mysqli_query($conn,"select email  from students WHERE student_id = '{$username}'"),MYSQLI_ASSOC);  
			$random_number = rand(1000, 9999); 
			
			require_once '../PHP/mal2.php'; 
			if($arrstu!=null){  
			sendemails($arrstu[0],$random_number,"reset password"); 
			echo $random_number;   
						exit; 
				
			} 
			if($arrdoc!=null){  
			sendemails($arrdoc[0],$random_number);  
			echo $random_number;  
						exit; 
				
			} 
		}



	} 

?>