<?php


/* This code is establishing a connection to a MySQL database using the mysqli extension in PHP. It
sets the database host, name, username, and password as variables, and then creates a new mysqli
object with those variables as parameters. If the connection fails, it will output an error message.
If the connection is successful, it will do nothing (commented out). */

$db_host = "localhost";
$db_name = "university_project";
$db_user = "root";
$db_password = "";

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else {

}







?>
