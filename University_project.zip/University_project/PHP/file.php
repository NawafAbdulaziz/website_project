<?php 
   require('./connctDB.php');
   if(isset($_FILES['files']) && isset($_POST['room_id'])  && isset($_POST['sender_id']) ){
      $title = get_title($_POST['room_id']);

      $errors= array();

      foreach($_FILES['files']['tmp_name'] as $key => $tmp_name ){
         $file_name = $_FILES['files']['name'][$key];
         $file_size =$_FILES['files']['size'][$key];
         $file_tmp =$_FILES['files']['tmp_name'][$key];
         $file_type=$_FILES['files']['type'][$key];



          //    التاكد من حجم الملف
         if($file_size > 2097152){
            $errors[]='حجم الملف يجب أن يكون أقل من 2 ميغابايت' . $file_size;
         }

         date_default_timezone_set('Asia/Riyadh');
         $file_extension = pathinfo($file_name, PATHINFO_EXTENSION);
         $fn_without_extension = pathinfo($file_name, PATHINFO_FILENAME);


            // التاكد من امتدادات الملف
            $allowed_extensions = array('jpg', 'jpeg', 'png', 'gif','mp4', 'txt' , 'pdf' , 'doc' , 'docx' , 'ppt', 'pptx' , 'zip');

            if(!in_array(strtolower($file_extension), $allowed_extensions)){
               $errors[] = 'يسمح فقط بملفات الصور بامتدادات jpg, jpeg, png, gif,MP4, TXT , PDF , DOC , DOCX , PPT, PPTX , zip';
            }



         // قم بتحميل الملفات إلى مجلد مؤقت أو مجلد محدد
         $desired_dir="../uplode/" . $title ;
         if(empty($errors)==true){
         
            $new_name = $fn_without_extension . " " . date("Y-m-d") . " at " . date("h-i-s a") . ".". $file_extension;
            if(move_uploaded_file($file_tmp,"$desired_dir/".$new_name)==false){
               $errors[]='حدث خطأ أثناء رفع الملف';
            }
            if(empty($errors)){
               insert_file("$desired_dir/".$new_name , $_POST['room_id'] , $_POST['sender_id'] );
            }

         }
      }


      
      if(empty($errors)){

            echo trim("تم رفع الملفات بنجاح");
         
         
      }else{
         print_r($errors);// eror
      }
   }



   function get_title($room_id){
      require('./connctDB.php');

      $title=mysqli_fetch_all( mysqli_query($conn,"select title  from room WHERE id = '{$room_id}'"),MYSQLI_ASSOC); 

      return $title[0]["title"];

   }



   function insert_file($path , $room_id , $sender_id){
      require('./connctDB.php');

      $date =  date("Y-m-d H:i:s");
      $title= mysqli_query($conn,"INSERT INTO `files` ( `path`, `date`, `room_id`, `sender_id`)
      VALUES ( '{$path}', '{$date}', '{$room_id}', '{$sender_id}');"); 

      return "done successfully";

   }


   if(isset($_POST['room_id']) && isset($_POST['get_room'])){
      require('./connctDB.php');

      $room_id = $_POST['room_id'];
      $array_files=mysqli_fetch_all( mysqli_query($conn,"SELECT * FROM `files` WHERE `room_id` ='{$room_id}'"),MYSQLI_ASSOC); 


      if($array_files!=null){ 

         print_r(  json_encode($array_files) ) ; 
         exit;   
      }
      else{
         echo "null";
         exit;   
      }
   }


?>