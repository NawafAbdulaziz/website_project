<?php



    /* This code is checking if the variables `['fun_name']` and `['emails']` are set. If
    they are set, it checks if the value of `['fun_name']` is equal to "sendemails". If it is,
    it calls the function `sendemails()` and passes an array of email addresses obtained by
    exploding the string `['emails']` using comma as the delimiter. */
    if(isset($_POST['fun_name'])&&isset($_POST['emails'])) {
        // تنفيذ الدالة
        if($_POST['fun_name'] == "sendemails") {            
            $emails = explode(',', $_POST['emails']);;
            sendemails($emails);         
        }
    }



    /**
     * The function sends an email to a list of recipients with a predefined subject and body.
     * 
     * @param emails An array of email addresses to which the email will be sent.
     */
    function sendemails($emails,$mesg="The doctor added a new note, check it out",$Subject="New Note") { 
        require_once '../PHP/mail.php';
        $mail->setFrom('universityproject2023@gmail.com', 'University project');
        foreach ($emails as $item ) {
        $mail->addAddress($item);               

        }
        $mail->Subject = $Subject;
        $mail->Body    = $mesg;  
        $mail->send();
    }
    
?>
