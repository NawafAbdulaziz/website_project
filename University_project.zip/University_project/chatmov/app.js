/* The above code is setting up a Node.js server using the Express framework and Socket.IO library to
create a real-time chat application. The server listens for incoming connections from clients and
allows them to join rooms and send messages to other clients in the same room. The messages are
stored in a MySQL database and can be retrieved and displayed when a client joins a room. The code
also includes middleware functions for logging incoming requests to the console. The server is set
up to listen for incoming requests on port 3000 and can be exported for use in other files. */

const path = require('path')
// Socket.IO
var createError = require('http-errors');
const logger = require('morgan')

const express = require('express')
const app = express()
const http = require('http').Server(app)

/* This code is setting up a Socket.IO server that listens for connections from clients. The
`require('socket.io')` function returns a function that takes an HTTP server object as its argument.
The `http` object is created using the `express` application object (`const app = express()`) and
the `http` module (`const http = require('http').Server(app)`). The `cors` object is an optional
configuration object that specifies the allowed origins and methods for cross-origin requests. The
resulting `io` object is an instance of the Socket.IO server that can be used to listen for events
and emit messages to connected clients. */
const io = require('socket.io')(http, {
  cors:{
    origin: "http://localhost",
    methods: ["GET", "POST"]
  }
});

/* This code is setting up a server to listen for incoming requests on port 3000. The `http.listen()`
method starts the server and listens for incoming requests on the specified port. When the server
starts, it logs a message to the console indicating that it is listening on the specified port. */
const port = 3000
// Start the server
http.listen(port, () => {
  console.log('Listening on port ' + port)
})


/* `const mysql = require("mysql");` is importing the `mysql` module, which is a Node.js module that
provides a way to interact with MySQL databases. It allows the server to create connections to a
MySQL database, execute queries, and retrieve results. The module is used in this code to insert and
retrieve messages from a MySQL database. */
const mysql = require("mysql");




// middleware

/* `app.use(logger('dev'))` is a middleware function that logs information about incoming requests to
the console. The 'dev' parameter specifies the log format, which includes the HTTP method, URL,
status code, response time, and size of the response body. This is useful for debugging and
monitoring the server's activity. */
app.use(logger('dev'))
/////////

/* This code is setting up a Socket.IO server that listens for connections from clients. When a client
connects, it logs a message to the console and sets up event listeners for various events that can
occur during the connection. */
io.on('connection', function(socket) {

  console.log("user connected");


  /* This code is creating a room for the socket connection and joining the socket to that room. The
  `room_id` variable is initially declared as undefined, and when the socket receives a 'joinroom'
  event, it sets the `room_id` variable to the value of `data.jonroom` (which is presumably a unique
  identifier for the room), and then joins the socket to that room using `socket.join(room_id)`.
  This allows the socket to communicate with other sockets that are also joined to the same room. */
  var room_id;
  socket.on('joinroom', function(data) {
    room_id = data.jonroom;
    socket.join(room_id);
  });




  /* This code is listening for a 'message' event from the socket connection. When it receives a
  'message' event, it logs the user and message to the console, emits a 'msg serv' event to all
  sockets in the same room as the current socket (using `io.to(room_id).emit()`), and calls the
  `insert()` function with the `message` object as an argument. The `insert()` function inserts the
  message into a MySQL database. */
  socket.on('message', function(message) {
    console.log("user: " + message.user + " value: " + message.mes);// don't care about

    io.to(room_id).emit("msg serv", { "user": message.user, "msg": message.mes });

    insert(message);
  });



  /**
   * This function inserts a message into a MySQL database with information about the content, sender,
   * date, and room.
   * param message - an object containing the message content, sender ID, and room ID
   */
  function insert(message) {
    var now = new Date();
    var date = now.getFullYear() + '-' + (now.getMonth() + 1) + '-' + now.getDate();

    var mysql = require('mysql');
    var connection = mysql.createConnection({
      host: 'localhost',
      user: 'root',
      password: '',
      database: 'university_project'
    });

    connection.connect();

    connection.query("INSERT INTO `message`( `content`, `sender_id`, `date`, `room_id`) VALUES " +
        "('" + message.mes + "','" + message.user + "','" + date + "','" + room_id + "')", function(error, results, fields) {
      if (error) throw error;
    });

    connection.end();
  };



 /* This code is listening for a 'disconnect' event from the socket connection. When a socket
 disconnects from the server, this event is triggered and the function logs "user disconnected" to
 the console. */
  socket.on('disconnect', function() {
    console.log("user disconnected");
  });



  /* This code is listening for a 'load' event from the socket connection. When it receives a 'load'
  event, it creates a MySQL connection to the database 'university_project', and queries the
  database for all messages in the room with the ID specified by the `room_id` variable. If the
  query is successful, it emits a 'load2' event to all sockets (using `io.emit()`) with the message
  data as an object with the key 'msg' and the value of the query results. If there is an error with
  the query, it logs the error to the console. */
  socket.on('load', function() {
    var mysql = require('mysql');
    var connection = mysql.createConnection({
      host: '127.0.0.1',
      user: 'root',
      password: '',
      database: 'university_project'
    });

    connection.connect();
    connection.query(`SELECT * FROM message WHERE room_id = '${room_id}'`, function(error, results, fields) {
      if (!error) {


        io.emit("load2", { msg: results });


      } else {
        console.log(error);
      }
    });

    connection.end();
  });



});

/* `module.exports = app;` is exporting the `app` object, which is an instance of the Express
application, to be used in other files. This allows other files to access and use the routes and
middleware defined in the `app` object. */
module.exports = app;

