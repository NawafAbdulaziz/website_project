/* This code is adding an event listener to the document object that listens for the "DOMContentLoaded"
event, which is fired when the initial HTML document has been completely loaded and parsed. Once the
event is fired, the code checks if the "username" key exists in the sessionStorage object. If it
does, it retrieves the values of the "first_name", "last_name", and "email" fields from the HTML
document and sends an AJAX request to the server using the XMLHttpRequest object to retrieve the
user's data from the server. Once the data is retrieved, it populates the corresponding fields in
the HTML document with the retrieved data. */
document.addEventListener("DOMContentLoaded", () => { 

    if(sessionStorage.username != null){
        first_name=document.getElementById("first_name"); 
        last_name=document.getElementById("last_name");
        email=document.getElementById("email");

        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange=function(){   
            if(xhr.readyState == 4 && xhr.status == 200){

                first_name.value =JSON.parse(xhr.responseText)[0]["first_name"];
                last_name.value=JSON.parse(xhr.responseText)[0]["last_name"];
                email.value=JSON.parse(xhr.responseText)[0]["email"];

                } 
        }

        xhr.open("POST","../PHP/read.php",true);
        xhr.setRequestHeader ("Content-type", "application/x-www-form-urlencoded");
        xhr.send("username="+sessionStorage.username +"&getdata")
    }
})


// <! -!!! Not checked!!! ->
//This function is not working, I will work on it later
function save() {
    if(sessionStorage.username != null){
        const first_name = document.getElementById("first_name").value;
        const last_name = document.getElementById("last_name").value;
        const email = document.getElementById("email").value;
        const password = document.getElementById("password").value;
        const confirm_password = document.getElementById("confirm_password").value;

        var request = new XMLHttpRequest();
        request.onreadystatechange = function() {   
            if (request.readyState == 4 && request.status == 200) {            
                document.getElementById("span").innerHTML=request.responseText;
            } 
        };
        //غير موجود creat.php
        request.open("POST", "../PHP/create.php", true);
        request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        request.send("username=" + sessionStorage.username + "&first_name=" + first_name + "&last_name=" + last_name + "&email=" + email+ "&password=" + password + "&confirm_password=" + confirm_password  + "&seveprofile");
    }
}