
function heder_of_note() {
  document.getElementById(
    "ul_note"
  ).innerHTML = `<li class=" li_task " style=" background-color: #519b49;">
                <!--title heder-->
                <div  class="head_titel_task  div_task">
                    my jobs
                </div> 
                <!--// title heder //-->
                
                <!--add butoon -->
                <button  class=" add_task button_task"  style=" display: ${
                  parseInt(sessionStorage.leverage) == 0
                    ? "none"
                    : "block"
                };" onclick="create_note(${roomId})">
                    <span class="material-symbols-outlined">
                    add
                    </span>
                </button>
                <!--add butoon -->
            
                </li>
                `;
}


/* The above code is written in JavaScript and it is adding an event listener to the document object
that waits for the DOM to be fully loaded. Once the DOM is loaded, it retrieves the query string
parameters from the URL and assigns the value of the "id" parameter to the variable "roomId". It
then sets the href attribute of the first anchor tag to "text_box.html?roomId={roomId}" and sets the
innerHTML of the h1 element to the value of roomId. */
let roomId 
    document.addEventListener("DOMContentLoaded", () => {   

      const queryString = window.location.search;
      const urlParams = new URLSearchParams(queryString);
       roomId = urlParams.get('id');
      document.getElementsByTagName("a")[0].href=`text_box.html?roomId=${roomId}`;
      document.getElementById("h1").innerHTML=roomId;
      document.getElementsByTagName("a")[1].href=`file.html?roomId=${roomId}`


});



/* The above code is written in JavaScript and it is an event listener that listens for the
DOMContentLoaded event. If the roomId variable is not null, it sends an AJAX request to the server
using XMLHttpRequest to read notes related to the roomId. If the response is "The room has no
Notes", it displays a message on the console and adds a list item with a header and an add button to
the HTML page. Otherwise, it calls the display_note function to display the notes on the HTML page.
Finally, it calls the is_exists_students function. */
document.addEventListener("DOMContentLoaded", () => {

  if (roomId != null) {
    var request = new XMLHttpRequest();
    request.onreadystatechange = function () {
      if (request.readyState == 4 && request.status == 200) {
        if (request.responseText == "The room has no Notes") {
          console.log(request.responseText);
          heder_of_note()
        } else {
          display_note(JSON.parse(request.responseText));
        }
      }
    };
    request.open("POST", "../PHP/read.php", true);
    request.setRequestHeader(
      "Content-type",
      "application/x-www-form-urlencoded"
    );

    request.send("room_id=" + roomId + "&get_notes");
  } else {
    console.log("The room ID has no value");
  }

  is_exists_students();
});




/**
 * The function checks if there are existing students in a specified room and displays them if they
 * exist.
 */
function is_exists_students() {
  console.log("is_exists_students");
  if (roomId != null) {
    var request = new XMLHttpRequest();
    request.onreadystatechange = function () {
      if (request.readyState == 4 && request.status == 200) {
        if (request.responseText == "null") {
          console.log(request.responseText);
        } else {
          display_student(JSON.parse(request.responseText));
        }
      }
    };
    request.open("POST", "../PHP/read.php");
    request.setRequestHeader(
      "Content-type",
      "application/x-www-form-urlencoded"
    );

    request.send("room_id=" + roomId + "&get_stu");
  } else {
    console.log("log agin");
  }
}




/**
 * The function displays notes on a webpage and allows for updating, deleting, and marking notes as
 * done.
 * @param Notes - an array of objects representing notes to be displayed on the page. Each object
 * should have the following properties:
 */
function display_note(Notes) {
  console.log("display_note");

  heder_of_note()
  for (Note of Notes) {
    console.log(parseInt(sessionStorage.leverage) == 0 ? "none" : "block");
    document.getElementById(
      "ul_note"
    ).innerHTML += `<li class=" li_task"style="background-color: ${
      parseInt(Note["is_done"]) ? "rgb(56, 121, 56)" : ""
    };" > <div  class="one_task div_task">${
      Note["title"]
    }<p >${Note.date}</p></div>      
            
            <div class="two_task div_task" style=" display: ${
              parseInt(sessionStorage.leverage) == 0 ? "none" : "block"
            };" > 
            <button class="button_task"   onclick="update_note(${
              Note["id"]
            },${parseInt(
      Note["room_id"]
    )})"><span class="material-symbols-outlined">update</span></button> 
            <button class="button_task"  onclick="delete_note(${
              Note["id"]
            },${parseInt(
      Note["room_id"]
    )})"><span class="material-symbols-outlined">delete</span></button>   
            <button class="button_task"  id=${Note["id"]} onclick="done(${
      Note["id"]
    },${parseInt(Note["is_done"])},${Note["room_id"]})">${
      parseInt(Note["is_done"])
        ? '<span class="material-symbols-outlined">dangerous</span>'
        : '<span class="material-symbols-outlined">done</span>'
    }</button>
            
            </div> </li>
        `;
  }
}




/**
 * The function displays a list of students with their first and last names, and a delete button for
 * each student if the user has sufficient privileges.
 * @param Students - an array of objects representing students, with each object containing properties
 * such as first_name, last_name, student_id, and id_room.
 */
function display_student(Students) {
  console.log("display_stu");

  document.getElementById(
    "ul_students"
  ).innerHTML = `<li class=" li_task " style=" background-color: #519b49;">
        <!--title heder-->
        <div  class="head_titel_task  div_task">
        students present
        </div> 
        
        
    
        </li>`;
  for (Student of Students) {
    document.getElementById(
      "ul_students"
    ).innerHTML += `<li class=" li_task"<p >${
      Student["first_name"]
    }  ${Student.last_name}</p></div>      
            
            <div class="two_task div_task"  style=" display: ${
              parseInt(sessionStorage.leverage) == 0 ? "none" : "block"
            };" > 
            <button class="button_task"  onclick="delet_stu('${
              Student["student_id"]
            }',${
      Student["id_room"]
    })"><span class="material-symbols-outlined">delete</span></button>   
            
            </div> </li>
        `;
  }
}





/**
 * The function creates a new note with a title and adds it to a database for a specific room, and
 * sends an email to each student in the room.
 * @param room_id - The ID of the room where the note will be created.
 */
function create_note(room_id) {
  console.log("add");
  title = prompt(" Enter the new title ");
  if (room_id && title) {
    var request = new XMLHttpRequest();
    request.onreadystatechange = function () {
      if (request.readyState == 4 && request.status == 200) {
        if (
          request.responseText == "smothing wrong1" ||
          request.responseText == "smothing wrong2"
        ) {
          console.log(request.responseText);
        } else {
          console.log(request.responseText);
          display_note(JSON.parse(request.responseText));
          console.log(request.responseText);
          //Send the email to each student
          send_to_students();
        }
      }
    };

    request.open("POST", "../PHP/create.php", true);
    request.setRequestHeader(
      "Content-Type",
      "application/x-www-form-urlencoded"
    );
    request.send(
      "query=" +
        `INSERT INTO note (title, is_done, date, room_id) VALUES ('${title}', 0, NOW(), ${room_id})` +
        "&creat_note" +
        "&room_id=" +
        room_id
    );
  }
}




/**
 * The function updates the "is_done" status of a note in a database and displays the updated note.
 * @param id_note - The ID of the note that needs to be updated.
 * @param is_done - A boolean value indicating whether the note is marked as done or not.
 * @param room_id - The ID of the room where the note is located.
 */
function done(id_note, is_done, room_id) {
  console.log("done");
  if (id_note != null) {
    var request = new XMLHttpRequest();
    request.onreadystatechange = function () {
      if (request.readyState == 4 && request.status == 200) {
        if (request.responseText == "smothing wrong1") {
          console.log(request.responseText);
        } else {
          display_note(JSON.parse(request.responseText));
        }
      }
    };
    request.open("POST", "../PHP/updet.php", true);
    request.setRequestHeader(
      "Content-type",
      "application/x-www-form-urlencoded"
    );

    request.send(
      "query=" +
        `UPDATE note SET is_done = ${!parseInt(
          is_done
        )} WHERE id = ${id_note}` +
        "&update_note" +
        "&room_id=" +
        parseInt(room_id)
    );
  } else {
    console.log("log ID the note has no value");
  }
}




/**
 * The function updates a note's title in a database using an XMLHttpRequest.
 * @param id - The ID of the note that needs to be updated.
 * @param room_id - The ID of the room where the note is located.
 */
function update_note(id, room_id) {
  console.log("update");

  const New_note = prompt(" Enter the new title ");
  if (New_note != null) {
    var request = new XMLHttpRequest();
    request.onreadystatechange = function () {
      if (request.readyState == 4 && request.status == 200) {
        if (
          request.responseText == "smothing wrong" ||
          request.responseText == "smothing wrong2"
        ) {
          console.log(request.responseText);
        } else {
          display_note(JSON.parse(request.responseText));
        }
      }
    };

    request.open("POST", "../PHP/updet.php", true);
    request.setRequestHeader(
      "Content-Type",
      "application/x-www-form-urlencoded"
    );
    request.send(
      "query=" +
        `UPDATE note SET title='${New_note}' WHERE id=${id}` +
        "&update_note" +
        "&room_id=" +
        room_id
    );
  }
}




/**
 * The function deletes a note from a database using an XMLHttpRequest in JavaScript.
 * @param id - The ID of the note to be deleted.
 * @param room_id - The ID of the room where the note is located. This is used as a parameter in the
 * AJAX request to update the note list after the note is deleted.
 */
function delete_note(id, room_id) {
  console.log("delet");
  if (id != null && id != room_id) {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
      if (xhr.readyState == 4 && xhr.status == 200) {
        if (xhr.responseText == "null" ) { 
         heder_of_note()       
          console.log(xhr.responseText);
        } else {
          display_note(JSON.parse(xhr.responseText));
        }
      }
    };

    xhr.open("POST", "../PHP/updet.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.send(
      "query=" +
        `DELETE FROM note WHERE id=${id}` +
        "&delete_note" +
        "&room_id=" +
        room_id
    );
  }
}




/**
 * The function deletes a student from a database using an XMLHttpRequest in JavaScript.
 * @param id - The ID of the student to be deleted from the database.
 * @param room_id - The ID of the room from which the student is being deleted.
 */
function delet_stu(id, room_id) {
  console.log("delet_stu");
  if (id != null && room_id != null) {
    alert(id + " " + room_id);
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
      if (xhr.readyState == 4 && xhr.status == 200) {
        if (
          xhr.responseText == "smothing wrong" ||
          xhr.responseText == "smothing wrong2"
        ) {
          console.log(xhr.responseText);
        } else {
          console.log(id);
          console.log(xhr.responseText);
          display_student(JSON.parse(xhr.responseText));
        }
      }
    };

    xhr.open("POST", "../PHP/read.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    xhr.send(
      "query=" +
        `DELETE FROM text_box WHERE student_id = '${id}'` +
        "&get_stu" +
        "&room_id=" +
        parseInt(room_id) +
        "&delete=" +
        id
    );
  }
}
