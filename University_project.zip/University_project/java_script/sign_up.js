let username = document.getElementById("username");
let first_name = document.getElementById("first_name");
let last_name = document.getElementById("last_name");
let email = document.getElementById("email");
let password = document.getElementById("password");
let confirm_password = document.getElementById("confirm_password");
let go = document.getElementById("go");


let C_password;


//هذا المتغير قيمته الافتراضية هي true ولكن عند حدوث خطا في الادخال يصبح قيمته false ولا يمكن ارسال form  الا اذا كان true
let isValidate = [false, false, false, false, false, false];



//**************************************************************** */


// ارسال username الي php للتحقق من البيانات المدخلة
username.addEventListener("blur", function () {
  const request = new XMLHttpRequest();

  request.onreadystatechange = function () {
    if (request.readyState == 4 && request.status == 200) {

      sp_username = document.getElementById("sp_username");

      // console.log(username.value + "-- =>"+ request.responseText)

      if (username.value !== request.responseText) {
        // console.log("hello");
        sp_username.innerHTML = request.responseText;
        isValidate[0] =  false;
      } 
      else {
        // console.log("helloo");
        sp_username.innerHTML = " ";
        username.value = request.responseText.trim();
        isValidate[0] =  true;

        // console.log(username.value + "-- =>"+ request.responseText);
      }
    }
  };
  request.open("post", "../PHP/create.php", true);
  request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

  request.send("username=" + username.value);
});





// ارسال first_name الي php للتحقق من البيانات المدخلة
first_name.addEventListener("blur", function () {
  const request = new XMLHttpRequest();

  request.onreadystatechange = function () {
    if (request.readyState == 4 && request.status == 200) {
      sp_first_name = document.getElementById("sp_first_name");

      // console.log(first_name.value + "-- =>"+ request.responseText);

      if (first_name.value !== request.responseText) {
        // console.log("hello");

        sp_first_name.innerHTML = request.responseText;
        isValidate[1] =  false;
      } 
      else {
        // console.log("helloo");
        
        sp_first_name.innerHTML = " ";
        first_name.value = request.responseText.trim();
        isValidate[1] =  true;

        // console.log(first_name.value + "-- =>"+ request.responseText);
      }
    }
  };

  request.open("POST", "../PHP/create.php");

  request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

  var requestBody = "first_name=" + first_name.value;

  request.send(requestBody);
});




// ارسال last_name الي php للتحقق من البيانات المدخلة
last_name.addEventListener("blur", function () {
  const request = new XMLHttpRequest();

  request.onreadystatechange = function () {
    if (request.readyState == 4 && request.status == 200) {
      sp_last_name = document.getElementById("sp_last_name");

      if (last_name.value !== request.responseText) {

        sp_last_name.innerHTML = request.responseText;
        isValidate[2] =  false;

      } else {
        sp_last_name.innerHTML = "";
        last_name.value = request.responseText.trim();
        isValidate[2] =  true;

        // console.log(last_name.value + "-- =>"+ request.responseText);
      }
    }
  };

  request.open("POST", "../PHP/create.php");

  request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

  var requestBody = "last_name=" + last_name.value;

  request.send(requestBody);
});





// ارسال email الي php للتحقق من البيانات المدخلة
email.addEventListener("blur", function () {
  const request = new XMLHttpRequest();

  request.onreadystatechange = function () {
    if (request.readyState == 4 && request.status == 200) {
      sp_email = document.getElementById("sp_email");

      // console.log(email.value + "-- =>"+ request.responseText);

      if (email.value !== request.responseText) {
        // console.log("hello");

        sp_email.innerHTML = request.responseText;
        isValidate[3] =  false;
      } 
      else {
        // console.log("helloo");

        sp_email.innerHTML = " ";
        email.value = request.responseText.trim();
        isValidate[3] =  true;


        // console.log(email.value + "-- =>"+ request.responseText);
      }
    }
  };

  request.open("POST", "../PHP/create.php");

  request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

  var requestBody = "email=" + email.value;

  request.send(requestBody);
});





// ارسال password الي php للتحقق من البيانات المدخلة
password.addEventListener("blur", function () {
  const request = new XMLHttpRequest();

  request.onreadystatechange = function () {
    if (request.readyState == 4 && request.status == 200) {
      sp_password = document.getElementById("sp_password");

      // console.log(password.value + "-- =>"+ request.responseText);

      if (password.value !== request.responseText) {
        // console.log("hello");

        sp_password.innerHTML = request.responseText;
        isValidate[4] =  false;

      }
       else {
        // console.log("helloo");\
        sp_password.innerHTML = " ";
        password.value = request.responseText;
        C_password = password.value;
        isValidate[4] =  true;

        // console.log(password.value + "-- =>"+ request.responseText);
      }
    }
    
  };

  request.open("POST", "../PHP/create.php");

  request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

  var requestBody = "password=" + password.value;

  request.send(requestBody);



});



// التأكد من ان confirm_password يساوي password عن طريق المتغير C_password
 /* This code is adding an event listener to the `password` input field that listens for any input
 changes. When the user types in the `password` field, the function is triggered. */
 confirm_password.addEventListener("input", function(){
   console.log("hhhh");

      sp_confirm_password = document.getElementById("sp_confirm_password");
      if (confirm_password.value == password.value) {
        sp_confirm_password.innerHTML = ``;
        isValidate[5] =  true;
  
      } else {
        sp_confirm_password.innerHTML = `password does not match`;
        isValidate[5] =  false;
      }
    });


    


//******************************************************************************** */



/* This code is adding an event listener to the "go" button that listens for a click event. When the
button is clicked, it checks whether the radio button with the name "is_doctor" is checked or not.
If it is checked, the variable `is_doctorPro` is assigned the value `true`, otherwise it is assigned
the value `false`. Then, it checks whether all the input fields in the form have been validated
successfully or not. It loops through the `isValidate` array which contains boolean values
indicating whether each input field has been validated or not. If all the values in the array are
`true`, then `isValidatePro` is assigned the value `true`, indicating that the form is ready to be
submitted. If any of the values in the array are `false`, then `isValidatePro` is assigned the value
`false`, indicating that the form is not ready to be submitted. If `isValidatePro` is `true` and
`is_doctorPro` is `true`, it sends an AJAX request to the server to submit the form data. Otherwise,
it logs an error message to the console. */
go.addEventListener("click" , () => {

  /* This code is selecting the radio button with the name "is_doctor" that is currently checked and
  assigning its value to the variable `is_doctorPro`. If no radio button is checked, `is_doctorPro`
  is assigned the value `false`. This is used to determine whether the user is a doctor or not when
  submitting the form. */
  const radioBtn = document.querySelector('input[name="is_doctor"]:checked');
  let is_doctorPro =false;

    if (radioBtn !== null) {
      is_doctorPro = true;
    } 
    else {
      is_doctorPro = false;
    }


  // ****************************************************

  /* This code is checking if all the input fields in the form have been validated successfully. It
  loops through the `isValidate` array which contains boolean values indicating whether each input
  field has been validated or not. If all the values in the array are `true`, then `isValidatePro`
  is assigned the value `true`, indicating that the form is ready to be submitted. If any of the
  values in the array are `false`, then `isValidatePro` is assigned the value `false`, indicating
  that the form is not ready to be submitted. */
  let isValidatePro ;
  for (let i = 0; i < isValidate.length; i++) {
    if(isValidate[i] === true){
      isValidatePro = true;
    }
    else{
      isValidatePro = false;
      break;
    }
    
  }
  // ****************************************************


  if( isValidatePro === true    &&   is_doctorPro === true ){
    const request = new XMLHttpRequest();

    request.onreadystatechange = function () {
      if (request.readyState == 4 && request.status == 200) {
        // console.log(xhr.responseText);
        console.log(request.responseText);
        if(request.responseText=="success"){
          window.location.href = "../index.html";// home
          sessionStorage.username=username;
          
        }
        else{
          document.getElementById("error_In_DB").innerHTML=request.responseText  ;
        }
      }
    };
    request.open("POST", "../PHP/create.php");
    // xhr.setRequestHeader ("Content-type", "application/x-www-form-urlencoded");

    const myform = document.getElementById("myform");
    const data = new FormData(myform);

    request.send(data);
  }
  else{
    console.log("error the form");
  }
  

})
