
/* These lines of code are selecting HTML elements with the IDs "chat_messages" and "chat_box_body" and
assigning them to the variables `chat_messages` and `chat_box_body`, respectively. These variables
are likely used later in the code to manipulate the contents and appearance of the chat box. */
var chat_messages = document.getElementById("chat_messages");

var chat_box_body = document.getElementById("chat_box_body");


/* This code is adding an event listener to the `DOMContentLoaded` event, which fires when the initial
HTML document has been completely loaded and parsed. Inside the event listener, a new socket
connection is created to a server at the specified URL using the `io` library. The `socket` variable
is then used to emit and receive events between the client and server. */
document.addEventListener("DOMContentLoaded", () => {

/* This line of code is creating a new socket connection to the server at the specified URL
(`http://localhost:3000/`) using the `io` library. The `socket` variable is then used to emit and
receive events between the client and server. */
    const socket = io.connect("http://localhost:3000/");



/* This line of code is emitting a 'joinroom' event to the server using the `socket` variable and
passing an object with a property 'jonroom' and a value of `roomId`. The purpose of this event is
likely to inform the server that the client has joined a specific chat room or channel identified by
`roomId`. */
    socket.emit('joinroom', { jonroom: roomId });



    var chatInput = document.getElementById("chat_input");
    chatInput.addEventListener("keyup", function(event) {
        
        if (event.key === "Enter" && event.shiftKey) {
             // منع إضافة السطر الجديد
            // يتم تنفيذ الإجراءات الأخرى هنا
          }
        else if (event.key === "Enter") {
            event.preventDefault(); // منع إضافة السطر الجديد
            document.getElementById("send").click(); // نقر على زر الإرسال
            return false; // إيقاف عملية الإرسال
        }
    });
    
    
   /* This code is adding an event listener to the submit event of a form element. When the form is
   submitted, it first checks if the value of the input field with the ID "chat_input" is not empty.
   If it is empty, the function returns false to prevent the form from being submitted. */
    $('form').submit(function() {

        if ($('#chat_input').val().trim() === '') { // التحقق من أن النص غير فارغ
          return false; // إيقاف عملية الإرسال
        }
      
        socket.emit('message', { "mes": $('#chat_input').val(), "user": sessionStorage.username });
        $('#chat_input').val('');
        return false;
      });
    



    
/* `let Previous_message_sender` is declaring a variable named `Previous_message_sender` using the
`let` keyword. It is likely used to keep track of the sender of the previous message in the chat, so
that the chat interface can display the sender's name and profile picture only once for consecutive
messages from the same sender. */
    let Previous_message_sender

   

  

/* This code is emitting a 'load' event to the server using the `socket` variable, which is likely used
to request the previous chat messages for the current chat room or channel. When the server responds
with the previous messages, the `load2` event is triggered and the callback function is executed. */
    socket.emit('load');
    var bol = true;

    socket.on('load2', function(msg) {
        if (bol == true) {
            console.log(msg.msg);
            msg.msg.forEach(function(element) {
                // يعرض الرسائل اذا كنت اول مره تدخل ويغير لون الخلفيه حقت الرسيل
                if (element.sender_id ==  sessionStorage.username ) {

                    chat_messages.innerHTML+= `
                    
                    <div class="profile my-profile"  style=" display: ${Previous_message_sender == element.sender_id ? "none" : "block"};" >
                    <span>${element.sender_id}</span>
                  </div>


                  <div class="message my-message">
                    ${element.content}
                  </div>
                    `
                } else {

                    chat_messages.innerHTML+= `
                    <div class="profile other-profile"  style=" display: ${Previous_message_sender == element.sender_id ? "none" : "block"};">
                    <span>${element.sender_id}</span>
                  </div>


                  <div class="message other-message">
                  ${element.content}
                  </div>
                    `
                }        
                Previous_message_sender = element.sender_id
                window.scrollTo(0, document.body.scrollHeight);
            });
        }chat_box_body.scrollTo(0,chat_box_body.scrollHeight) ;
        bol = false;
    });







/* This code is listening for a 'msg serv' event emitted by the server using the `socket` variable.
When the event is received, the callback function is executed, which checks if the `msg.user`
property is equal to the current user's username stored in the `sessionStorage`. If it is, the
function adds HTML code to the `chat_messages` element to display the message as a "my-message" with
the user's profile picture and name on the right side of the chat box. If it is not, the function
adds HTML code to the `chat_messages` element to display the message as an "other-message" with the
sender's profile picture and name on the left side of the chat box. The `Previous_message_sender`
variable is used to keep track of the sender of the previous message in the chat, so that the chat
interface can display the sender's name and profile picture only once for consecutive messages from
the same sender. Finally, the function scrolls the chat box to the bottom to show the latest
message. */

        socket.on('msg serv', function(msg) {

        if (msg.user ==  sessionStorage.username ) {
            chat_messages.innerHTML+= `
                    
            <div class="profile my-profile" style=" display: ${Previous_message_sender == msg.user ? "none" : "block"};">
            <span>${msg.user}</span>
          </div>


          <div class="message my-message">
            ${msg.msg}
          </div>
            `
        } else {

            chat_messages.innerHTML+= `
            <div class="profile other-profile" style=" display: ${Previous_message_sender == msg.user ? "none" : "block"};">
            <span>${msg.user}</span>
          </div>


          <div class="message other-message">
          ${msg.msg}
          </div>
            `
        }
        Previous_message_sender = msg.user
        chat_box_body.scrollTo(0,chat_box_body.scrollHeight) ;
         window.scrollTo(0, document.body.scrollHeight);
    });

    

})
