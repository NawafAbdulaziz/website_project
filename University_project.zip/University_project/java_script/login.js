/* This code is adding an event listener to the HTML element with the ID "login". When the element is
clicked, it sends an XMLHttpRequest to a PHP file called "read.php" with the username and password
entered by the user as parameters. The PHP file will then check if the username and password are
valid and return a response of "success" or an error message. If the response is "success", the
username is stored in the session storage and the user is redirected to the "home.html" page. If
there is an error, the error message is displayed in an HTML element with the ID "span". */
document.getElementById("login").addEventListener("click", () => {
    var request = new XMLHttpRequest();
	username=document.getElementById("username").value;
	password=document.getElementById("password").value;
    request.onreadystatechange=function(){   
        if(request.readyState == 4 && request.status == 200){ 
			if(request.responseText=="success"){
                sessionStorage.setItem("username", username);
                window.location.href = "home.html";
				
			}else{
                // if username or password not valid will show to the user error
				document.getElementById("span").innerHTML=request.responseText  ;

			}



        } 
    }
    request.open("POST","../PHP/read.php",true);
    request.setRequestHeader ("Content-type", "application/x-www-form-urlencoded");

    request.send("username="+username+"&password="+password+"&login") 
})
   