
/* This code is adding an event listener to the HTML element with the ID "create_rooms". When this
element is clicked, it sends an HTTP POST request to the server using XMLHttpRequest. The request is
sent to the URL "../PHP/create.php" with a request header of "Content-type" set to
"application/x-www-form-urlencoded". The request body contains the values of the "title" and
"username" input fields, as well as a string "creat_room". */
document.getElementById("create_rooms").addEventListener("click", () => {
    const request = new XMLHttpRequest();
  
    request.onreadystatechange = function () {
      if (request.readyState == 4 && request.status == 200) {
        if (request.responseText == "sorry there is a room with this name") {
          alert("sorry there is a room with this name");
        } 
        else if(request.responseText == "suecssfly") {
          console.log(request.responseText);
          alert("creat suecssfly");
          window.location.href ="home.html";  
        }
        else{
          alert("somthing wrong");
        }
      }
    };
    request.open("POST", "../PHP/create.php");
    request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  
    const title = document.getElementById("title").value;
    const description = document.getElementById("description").value;
  

    request.send(
      "title=" + title + "&username=" + sessionStorage.username + "&creat_room" +
      "&description=" + description );
  });
  
  