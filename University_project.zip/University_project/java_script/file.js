/* These lines of code are retrieving the value of the "roomId" parameter from the URL query string and
storing it in the `roomId` variable. The `get_and_view_file()` function is then called to send a
POST request to a PHP file to retrieve and display a list of files in the specific chat room
identified by the `roomId`. */
const queryString = window.location.search;
const urlParams = new URLSearchParams(queryString);
const roomId = urlParams.get("roomId");

get_and_view_file();

/**
 * This function sends a POST request to a PHP file to retrieve and display a list of files in a
 * specific chat room.
 */
function get_and_view_file() {
  var request = new XMLHttpRequest();
  request.open("POST", "../PHP/file.php");
  request.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
  request.onreadystatechange = function () {
    if (request.readyState === 4 && request.status === 200) {
      if (request.responseText === "null") {
        //do nothing
        console.log(request.responseText);
      } else {
        let arr2 = JSON.parse(request.responseText);
        //make sure is it empty
        document.getElementById("file").innerHTML = ``;

        arr2.forEach((element) => {
          var filename = relative_path(element["path"]);
          document.getElementById("file").innerHTML += ` 
            <a download="${filename}" href="${element["path"]}" class="download-link">
            <div class="card">
            <img class="card-thumbnail" src="./photo/file_Image_download_icon-icons.com_68942.png" alt="File Thumbnail">
            <div class="card-description card-name">${filename}</div>
            <div class="card-name">${element["sender_id"]}
            </div>
            </a>`
        });
      }
    }
  };
  request.send("room_id=" + roomId + "&get_room");
}

/**
 * The function uploads files using XMLHttpRequest and FormData in JavaScript.
 */

function uploadFiles() {
  console.log(roomId);

  var fileInput = document.getElementById("fileInput");
  var formData = new FormData();
// for loop to stor files in array  that send by suer 
  for (var i = 0; i < fileInput.files.length; i++) {
    console.log(fileInput.files[i]);
    formData.append("files[]", fileInput.files[i]);
  }
  // ________________________________________

  const span = document.getElementById("span");
  var xhr = new XMLHttpRequest();

  xhr.onreadystatechange = function () {
    if (xhr.readyState == 4 && xhr.status == 200) {
      if (xhr.responseText == "تم رفع الملفات بنجاح") {
        console.log("تم رفع الملفات بنجاح");
        get_and_view_file();
        fileInput.value = "";
      } else {
        span.innerHTML = xhr.responseText;
        console.log(xhr.responseText);
        fileInput.value = "";
      }
    }
  };
  xhr.open("POST", "../PHP/file.php");

  formData.append("room_id", roomId);
  formData.append("sender_id", sessionStorage.username);
  xhr.send(formData);
}

/**
 * The function extracts the filename from a given relative path.
 * @returns the filename "Report 2023-06-02 at 10-05-29 pm.docx".
 */
function relative_path(path_name) {
  // to get name of the just file 
  var path = path_name;
  var parts = path.split("/");
  var filename = parts[parts.length - 1];
  return filename;
}
