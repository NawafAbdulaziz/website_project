/* This code is adding an event listener to the HTML element with the ID "join_rooms". When this
element is clicked, the code sends an HTTP POST request to the server using XMLHttpRequest. The
request includes the room ID and the username of the current user, and the server responds with a
message indicating whether the user has successfully joined the room or not. Depending on the
response, the code displays an alert message to the user. If the user has successfully joined the
room, the code also moves the user to the home.html page. */
document.getElementById("join_rooms").addEventListener("click", () => {
    console.log("hhhh");
    const request = new XMLHttpRequest();
    const room_id = document.getElementById("room").value;

    request.onreadystatechange = function () {
      if (request.readyState == 4 && request.status == 200) {
        if (request.responseText == "There is no room with this id") {
          alert("There is no room with this id");
        } else if (
          request.responseText ==
          "It is not allowed to register in more than one room"
        ) {
          alert("It is not allowed to register in more than one room");
        } else {
          console.log(request.responseText);
          alert("You have been registered successfully");

          // location.replace("http://localhost/University_project/HTML/room.html?id="+room_id);

          window.location.href ="room.html?id=" + room_id;

  
          //moving to home.html
        }
      }
    };
    request.open("POST", "../PHP/updet.php");
    request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  
    // const description = document.getElementById("description").value;
  
    request.send(
      "room=" + room_id + "&username=" + sessionStorage.username + "&join_room"
    );
  });
  