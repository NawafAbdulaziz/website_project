/* These lines of code are used to extract the value of the "roomId" parameter from the URL of the
current page. */
const queryString = window.location.search;

const urlParams = new URLSearchParams(queryString);

const roomId = urlParams.get('roomId');



  /* This code block is adding an event listener to the document object that waits for the DOM to be
  fully loaded before executing the code inside the function. Once the DOM is loaded, it checks if
  the `sessionStorage.username` is not null. If it is not null, it sends an AJAX request to a PHP
  file using the POST method with the `room` parameter set to the value of `roomId` extracted from
  the URL. The PHP file returns a response in JSON format, which is then parsed and used to
  dynamically generate HTML elements on the page. For each object in the JSON response, a label, a
  textarea, and a button are created and appended to the `boxs` element on the page. The `textarea`
  element is populated with the `content` property of the object, and the `button` element is given
  an `onclick` attribute that calls the `save` function with the `id_box` and `id_text` parameters.
  If the `sessionStorage.username` does not match the `student_id` property of the object, the
  `textarea` element is disabled and the `button` element is hidden. If the AJAX request encounters
  an error, an error message */
    document.addEventListener("DOMContentLoaded", () => {

        if(sessionStorage.username != null){
            var xhr = new XMLHttpRequest();
                xhr.onreadystatechange=function(){   
                    if(xhr.readyState == 4 && xhr.status == 200){
    
                    if(xhr.responseText=="smothing wrong"){
                        console.log(xhr.responseText);
                    }
                    else{
                        console.log(xhr.responseText);
    
                        let arr2=JSON.parse(xhr.responseText);
                        arr2.forEach(textarea => {  
    
                            document.getElementById("boxs").innerHTML+=`<label >${textarea.student_id}</label>
                            <textarea  id="${textarea.student_id}" ${sessionStorage.username != textarea.student_id? 'disabled' :""}>${textarea.content}</textarea>
                            <button style="display: ${sessionStorage.username != textarea.student_id? 'none' :"block"};" onclick="save(${textarea.id},'${textarea.student_id}')">save</button>
                            <br>
                            `                    
                        });
                    }
    
                } 
            }
            xhr.open("POST","../PHP/read.php",true);
            xhr.setRequestHeader ("Content-type", "application/x-www-form-urlencoded");
    
            xhr.send("room="+roomId+"&boxs") 
            
        }else{
        console.log("log agin");
        }
    });





/**
 * This function sends a POST request to a PHP file with data from a text box and an ID, and alerts the
 * user if the request was successful.
 * @param id_box - The id of the HTML element that represents the box where the content will be saved.
 * @param id_text - The id of the HTML element that contains the text content to be saved.
 */
function save(id_box,id_text) {

        var xhr = new XMLHttpRequest();
                xhr.onreadystatechange=function(){   
                    if(xhr.readyState == 4 && xhr.status == 200){
    
                    if(xhr.responseText=="smothing wrong"){
                        console.log(xhr.responseText);
                    }
                    else{
                        alert("Added successfully")
                        console.log(xhr.responseText);                
                    
                    }
                
    
                } 
            }
            xhr.open("POST","../PHP/read.php",true);
            xhr.setRequestHeader ("Content-type", "application/x-www-form-urlencoded");
            let content=document.getElementById(id_text).value
            xhr.send("query="+"&content="+content+`&id_box=`+id_box+"&boxs"+"&room="+roomId) 
    }

