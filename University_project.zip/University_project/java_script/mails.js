/**
 * This function retrieves a list of emails from a database based on a specific room ID and returns
 * them as an array.
 * @returns an array of emails of students in a specific room, or null if there are no students in that
 * room.
 */
function getemalis(){     
    var emails_json
    var request = new XMLHttpRequest();
    
    request.onreadystatechange=function(){   
        if(request.readyState == 4 && request.status == 200){                
            emails_json=request.response
            console.log(emails_json);
        } 
    }
    request.open("POST","../PHP/read.php",false);   
    request.setRequestHeader ("Content-type", "application/x-www-form-urlencoded");
    request.send("query=" + "SELECT  email FROM  students WHERE id_room="+parseInt(roomId) +"&specific_stud"); 

            if(emails_json != undefined ){
if(emails_json!="null specific_stud"){
    console.log(emails_json);
    var array_emails=JSON.parse(emails_json);
    var emails_only=[];
    for (let index = 0; index < array_emails.length; index++) {
    
        emails_only.push(array_emails[index].email);
        
        
        
    }  
    return emails_only;
}else{
    return null;

}
    
}
    
    }
    



/**
 * The function sends emails to students using an AJAX request and a PHP file.
 */
function send_to_students() { 
    var emails = getemalis();
    if(emails != null){
    console.log(emails);
  
    // إنشاء طلب AJAX
    var request = new XMLHttpRequest();

    // تعريف الدالة التي سيتم استدعاؤها في ملف PHP
    var data = new FormData();
    data.append("fun_name", "sendemails");
    data.append("emails", emails);
    // إرسال الطلب إلى ملف PHP
    request.open("POST", "../PHP/mal2.php", true);
    request.send(data);
        
    // استقبال الردمن ملف PHP
    request.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            // استخدام الرد من الدالة
            var result = this.responseText;
            console.log(result);
        }
    };
}
}