
/**
 * This function sends a request to a PHP file to retrieve room data and displays it on a webpage using
 * HTML and JavaScript.
 */
function display_rooms() {
    var request = new XMLHttpRequest();
    request.onreadystatechange = function () {
      if (request.readyState == 4 && request.status == 200) {
        if (request.responseText == "null" ) {
          console.log(request.responseText);
        } 
        else {
          let arr = JSON.parse(request.responseText);
          arr.forEach((element) => {
            document.getElementById( "cards").innerHTML +=
                ` <div class="card row" >
                <img src="./photo/photo1.jpeg" class="card-img-top" alt="...">
                <div class="card-body ">
                  <h5 class="card-title">${element["title"]}</h5>
                  <p class="card-text">${element["description"]}.</p>
                  <a href="room.html?id=${element["id"]}" class="btn btn-primary">Go to room</a>
                </div>
              </div>`;
          });

        }
      }
    };
    request.open("POST", "../PHP/read.php", true);
    request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  
    request.send("username=" + sessionStorage.username + "&get_room");
  }
  

  // -----------------------------------------------------------------------------------------------
  
  /**
   * The function checks if a username is stored in sessionStorage and sends a POST request to a PHP
   * file to retrieve the user's leverage value.
   */
  function username_in_sessionStorage() {
    var request = new XMLHttpRequest();
    request.onreadystatechange = function () {
    
      if (request.readyState == 4 && request.status == 200) {
        if (request.responseText == "smothing wrong") {
          console.log(request.responseText);
        } else {
          sessionStorage.leverage = request.responseText;
          const myLink = document.getElementById("myLink");
          // check if the user is student or doctor to determine leverage and chenge link to right path
          myLink.href =
            parseInt(sessionStorage.leverage) == 0
              ? "join_room.html"
              : "create_room.html";
          myLink.innerHTML =
          // changing the text content of the button
          `          
            <button class="btn1" >${parseInt(sessionStorage.leverage) == 0 ? "join" : "create"}</button>
          `
            
        }
      }
    };
    request.open("POST", "../PHP/read.php", true);
    request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  
    request.send("username=" + sessionStorage.username + "&get_leverage");
  }
  
  // -----------------------------------------------------------------------------------------------
  
 /* This code block is adding an event listener to the document object that listens for the
 "DOMContentLoaded" event, which fires when the initial HTML document has been completely loaded and
 parsed. Once this event is fired, the code checks if a username is stored in the sessionStorage. If
 a username is found, it calls the `display_rooms()` and `username_in_sessionStorage()` functions to
 display the rooms and retrieve the user's leverage value, respectively. If no username is found, it
 logs a message to the console. */
  document.addEventListener("DOMContentLoaded", () => {
    if (sessionStorage.username != null) {
      display_rooms();  
      username_in_sessionStorage();
    } else {
      console.log("login agin");
    }
  });
  